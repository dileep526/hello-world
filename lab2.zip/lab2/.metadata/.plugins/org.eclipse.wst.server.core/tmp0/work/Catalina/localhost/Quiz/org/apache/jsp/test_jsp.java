package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.sql.*;
import javax.sql.*;

public final class test_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<title>Test</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
 
String user=request.getParameter("user");
String coll=request.getParameter("coll");
String id=request.getParameter("id");


      out.write("\r\n");
      out.write("\r\n");
      out.write("Name:");
      out.print( user);
      out.write("<br>\r\n");
      out.write("College:");
      out.print( coll );
      out.write("<br>\r\n");
      out.write("Roll:");
      out.print(id );
      out.write("<br>\r\n");
      out.write("\r\n");

try{
	Class.forName("com.mysql.jdbc.Driver");  
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
	Statement st=con.createStatement();
	
	int res=st.executeUpdate("insert into quiz (name,roll,college)values ('"+user+"',"+id+",'"+coll+"')");
	
	out.println("You are permitted to write test");
}
catch(Exception e)
{e.printStackTrace();
}

      out.write("\r\n");
      out.write("\r\n");
      out.write("<center><h1><b>QUIZ</b></h1></center>\r\n");
      out.write("<form action=ans.jsp method=\"post\">\r\n");
      out.write("1.Who developed C language?<br>\r\n");
      out.write("<input type=\"radio\" name=\"1\" value=\"A\">James Goosling\r\n");
      out.write("<input type=\"radio\" name=\"1\" value=\"B\">Bjarne Stroustrup\r\n");
      out.write("<input type=\"radio\" name=\"1\" value=\"C\">Dennis Ritchie\r\n");
      out.write("<input type=\"radio\" name=\"1\" value=\"D\">Guido van Rossum\r\n");
      out.write("\r\n");
      out.write("<br><br>\r\n");
      out.write("\r\n");
      out.write("2.Who developed JAVA language?<br>\r\n");
      out.write("<input type=\"radio\" name=\"2\" value=\"A\">James Goosling\r\n");
      out.write("<input type=\"radio\" name=\"2\" value=\"B\">Bjarne Stroustrup\r\n");
      out.write("<input type=\"radio\" name=\"2\" value=\"C\">Dennis Ritchie\r\n");
      out.write("<input type=\"radio\" name=\"2\" value=\"D\">Guido van Rossum\r\n");
      out.write("\r\n");
      out.write("<br><br>\r\n");
      out.write("\r\n");
      out.write("3.Is C?<br>\r\n");
      out.write(" <input type=\"radio\" name=\"3\" value=\"A\">Object Oriented\r\n");
      out.write(" <input type=\"radio\" name=\"3\" value=\"B\">Procedure Oriented\r\n");
      out.write(" <input type=\"radio\" name=\"3\" value=\"C\">Script\r\n");
      out.write(" <input type=\"radio\" name=\"3\" value=\"D\">None\r\n");
      out.write(" \r\n");
      out.write(" <br><br>\r\n");
      out.write(" \r\n");
      out.write(" 4.What is Default package in JAVA?<br>\r\n");
      out.write(" <input type=\"radio\" name=\"4\" value=\"A\">util\r\n");
      out.write(" <input type=\"radio\" name=\"4\" value=\"B\">Scanner\r\n");
      out.write(" <input type=\"radio\" name=\"4\" value=\"C\">lang\r\n");
      out.write(" <input type=\"radio\" name=\"4\" value=\"D\">None\r\n");
      out.write(" \r\n");
      out.write(" <br><br>\r\n");
      out.write(" \r\n");
      out.write(" 5.Is String a datatype in C++?<br>\r\n");
      out.write(" <input type=\"radio\" name=\"5\" value=\"A\">Yes\r\n");
      out.write(" <input type=\"radio\" name=\"5\" value=\"B\">No\r\n");
      out.write("\r\n");
      out.write("<br><br>\r\n");
      out.write("\r\n");
      out.write(" 6.Which of the following is a property of constructor?<br>\r\n");
      out.write(" <input type=\"radio\" name=\"6\" value=\"A\">Initiate the Values<br>\r\n");
      out.write(" <input type=\"radio\" name=\"6\" value=\"B\">Name is same as class name<br>\r\n");
      out.write(" <input type=\"radio\" name=\"6\" value=\"C\">Called implicitly when object is created<br>\r\n");
      out.write(" <input type=\"radio\" name=\"6\" value=\"D\">All the above<br>\r\n");
      out.write("\r\n");
      out.write("<br><br>\r\n");
      out.write("\r\n");
      out.write(" 7.Which operator is overloaded in JAVA?<br>\r\n");
      out.write(" <input type=\"radio\" name=\"7\" value=\"A\">~\r\n");
      out.write(" <input type=\"radio\" name=\"7\" value=\"B\">*\r\n");
      out.write(" <input type=\"radio\" name=\"7\" value=\"C\">+\r\n");
      out.write(" <input type=\"radio\" name=\"7\" value=\"D\">/\r\n");
      out.write(" \r\n");
      out.write(" <br><br>\r\n");
      out.write(" \r\n");
      out.write("8.C supports?<br>\r\n");
      out.write(" <input type=\"radio\" name=\"8\" value=\"A\">ASCII\r\n");
      out.write(" <input type=\"radio\" name=\"8\" value=\"B\">Uni-Code\r\n");
      out.write(" <input type=\"radio\" name=\"8\" value=\"C\">Both\r\n");
      out.write(" <input type=\"radio\" name=\"8\" value=\"D\">None\r\n");
      out.write(" \r\n");
      out.write(" <br><br>\r\n");
      out.write(" \r\n");
      out.write(" 9.JAVA Supports?<br>\r\n");
      out.write(" <input type=\"radio\" name=\"9\" value=\"A\">ASCII\r\n");
      out.write(" <input type=\"radio\" name=\"9\" value=\"B\">Uni-Code\r\n");
      out.write(" <input type=\"radio\" name=\"9\" value=\"C\">Both\r\n");
      out.write(" <input type=\"radio\" name=\"9\" value=\"D\">None\r\n");
      out.write(" \r\n");
      out.write(" <br><br>\r\n");
      out.write(" \r\n");
      out.write(" 10.Which feature of the OOPS gives the concept of reusability?<br>\r\n");
      out.write(" <input type=\"radio\" name=\"10\" value=\"A\">Abstraction\r\n");
      out.write(" <input type=\"radio\" name=\"10\" value=\"B\">Encapsulation\r\n");
      out.write(" <input type=\"radio\" name=\"10\" value=\"C\">Inheritance\r\n");
      out.write(" <input type=\"radio\" name=\"10\" value=\"D\">None\r\n");
      out.write("\r\n");
      out.write("<br><br>\r\n");
      out.write("\r\n");
      out.write("<input type=hidden name=hid value=");
      out.print(id );
      out.write(">\r\n");
      out.write("<input type=submit>\r\n");
      out.write("</form>\r\n");
      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
